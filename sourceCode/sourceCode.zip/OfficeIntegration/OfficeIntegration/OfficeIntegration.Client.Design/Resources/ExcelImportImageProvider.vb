Imports System
Imports System.ComponentModel.Composition
Imports System.Globalization
Imports System.Windows.Media.Imaging

Imports Microsoft.LightSwitch.BaseServices.ResourceService

Namespace Resources

    <Export(GetType(IResourceProvider))>
    <ResourceProvider("OfficeIntegration.ExcelImport")>
    Public Class ExcelImportImageProvider
        Implements IResourceProvider

#Region "IResourceProvider Members"

        Public Function GetResource(ByVal resourceId As String, ByVal cultureInfo As CultureInfo) As Object Implements IResourceProvider.GetResource
            Return New BitmapImage(New Uri("/OfficeIntegration.Client.Design;component/Resources/ControlImages/ExcelImport.png", UriKind.Relative))
        End Function

#End Region

    End Class

End Namespace