﻿Partial Public Class ColumnMapper
    Inherits ConfirmDialog

    Public Sub New()
        InitializeComponent()
    End Sub

End Class
