﻿Partial Public Class ProcessingDialog
    Inherits ConfirmDialog

    Public Sub New()
        InitializeComponent()
    End Sub

End Class
