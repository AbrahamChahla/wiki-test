﻿Public Class ColumnMapping
    Public Sub New(ByVal OfficeColumnName As String, ByVal TableFields As List(Of FieldDefinition))
        Me.OfficeColumn = OfficeColumnName
        Me.TableFields = TableFields

        'Try match up the column name to the table property choice
        TableField = TableFields.Where(Function(f) f.Name = OfficeColumnName OrElse f.DisplayName = OfficeColumnName).FirstOrDefault()
    End Sub
    Public Sub New(OfficeColumnName As String, EntityFieldName As String, Optional StaticValue As Object = Nothing, Optional FormatDelegate As [Delegate] = Nothing)
        Me.OfficeColumn = OfficeColumnName
        Me.TableField = New FieldDefinition(EntityFieldName)

        If StaticValue IsNot Nothing Then
            Me.TableField.StaticValue = StaticValue
        End If

        If FormatDelegate IsNot Nothing Then
            Me.TableField.FormatDelegate = FormatDelegate
        End If
    End Sub
    Public Property OfficeColumn As String
    Public Property TableField As FieldDefinition
    Public Property TableFields As List(Of FieldDefinition)
End Class

