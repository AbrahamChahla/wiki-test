﻿Imports Microsoft.LightSwitch.Model

Public Class FieldDefinition
    Public Property Name As String
    Public Property DisplayName As String
    Public Property TypeName As String
    Public Property IsNullable As Boolean
    Public Property EntityType As IEntityType
    Public Property StaticValue As Object
    Public Property FormatDelegate As [Delegate]

    Public Sub New()

    End Sub

    Public Sub New(ByVal name As String, ByVal displayName As String, ByVal typeName As String, ByVal isNullable As Boolean, Optional ByVal staticValue As Object = Nothing, Optional ByVal formatDelegate As [Delegate] = Nothing)
        Me.Name = name
        Me.DisplayName = displayName
        Me.TypeName = typeName
        Me.IsNullable = isNullable
        Me.StaticValue = staticValue
        Me.FormatDelegate = formatDelegate
    End Sub

    Public Sub New(name As String)
        Me.Name = name
        Me.DisplayName = name
    End Sub

End Class
