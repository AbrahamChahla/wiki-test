﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes
<Assembly: AssemblyTitle("OfficeIntegration.Lspkg")> 
<Assembly: AssemblyDescription("A LightSwitch Extension providing integration capabilities with Microsoft Office 2010.")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("Office Integration Pack")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft 2011")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c82b438b-849b-422d-8f61-e619413236fd")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 