﻿Public Class SmtpServer
    Private sSmtpServer As String
    Private sSmtpUserId As String
    Private sSmtpPassword As String
    Private iSmtpPort As Integer

    Public Sub New()

    End Sub

    Public Sub New(ByVal sSmtpUserId As String, ByVal sSmtpServer As String, ByVal sSmtpPassword As String, ByVal iSmtpPort As Integer)
        Me.sSmtpUserId = sSmtpUserId
        Me.sSmtpServer = sSmtpServer
        Me.sSmtpPassword = sSmtpPassword
        Me.iSmtpPort = iSmtpPort
    End Sub

    Property SmtpServer() As String
        Get
            Return sSmtpServer
        End Get
        Set(value As String)
            sSmtpServer = value
        End Set
    End Property

    Property SmtpUserId() As String
        Get
            Return sSmtpUserId
        End Get
        Set(value As String)
            sSmtpUserId = value
        End Set
    End Property

    Property SmtpPassword() As String
        Get
            Return sSmtpPassword
        End Get
        Set(value As String)
            sSmtpPassword = value
        End Set
    End Property

    Property SmtpPort() As Integer
        Get
            Return iSmtpPort
        End Get
        Set(value As Integer)
            iSmtpPort = value
        End Set
    End Property

End Class
