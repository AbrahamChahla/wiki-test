Description
 
The Office Integration Pack is a LightSwitch extension that makes it easy to manipulate the 2010 versions of Excel, Word and Outlook in a variety of ways common in desktop business applications. Create documents, PDFs, spreadsheets, email and appointments using data from your LightSwitch applications.

![](Home_oip.png)